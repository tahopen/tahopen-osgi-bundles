/*!
 * Copyright 2010 - 2018 Hitachi Vantara.  All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package org.pentaho.osgi.platform.plugin.deployer.impl.handlers;

import org.pentaho.osgi.platform.plugin.deployer.api.PluginFileHandler;
import org.pentaho.osgi.platform.plugin.deployer.api.PluginHandlingException;
import org.pentaho.osgi.platform.plugin.deployer.api.PluginMetadata;
import org.w3c.dom.Document;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;

/**
 * Finds blueprint files embedded one directory down and moves it up where it can be picked up by OSGI
 * Created by nbaker on 7/21/16.
 */
public class BlueprintFileHandler implements PluginFileHandler {

  public static final String JAR = ".jar";
  public static final String XML = ".xml";
  public static final String OSGI_INF_BLUEPRINT = "OSGI-INF/blueprint/";

  @Override public boolean handles( String fileName ) {
    return fileName != null && fileName.contains( OSGI_INF_BLUEPRINT ) && fileName.endsWith( XML );
  }

  @Override public boolean handle( String relativePath, byte[] file, PluginMetadata pluginMetadata )
      throws PluginHandlingException {
    try {
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      documentBuilderFactory.setFeature( XMLConstants.FEATURE_SECURE_PROCESSING, true );
      documentBuilderFactory.setFeature( "http://apache.org/xml/features/disallow-doctype-decl", true );
      documentBuilderFactory.setNamespaceAware( true );
      Document blueprint =
        documentBuilderFactory.newDocumentBuilder().parse( new ByteArrayInputStream( file ) );
      pluginMetadata.setBlueprint( blueprint );
    } catch ( Exception e ) {
      e.printStackTrace();
    }
    return false;
  }
}

